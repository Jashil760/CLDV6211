﻿using Microsoft.AspNetCore.Mvc;
using RideYouRentjr2.Models;
using System.Diagnostics;

namespace RideYouRentjr2.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}