﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ICSharpCode.Decompiler.CSharp.Syntax;
using Microsoft.AspNetCore.Mvc;
using RideYouRentjr2.Models;

namespace RideYouRentjr2.Controllers
{
    [CustomAuthorize(Roles = "Inspector")]
    public class CarController : Controller
    {
        private CarController db = new CarController();

        // GET: Car_ST10054051
        public ActionResult Index()
        {
            return View(db.Car_ST10054051.ToList());
        }

        // GET: Car_ST10054051/Details/5
        public ActionResult Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Car_ST10054051 car_ST10054051 = db.Car_ST10054051.Find(id);
            if (car_ST10054051 == null)
            {
                return HttpNotFound();
            }
            return View(car_ST10054051);
        }

        // GET: Car_ST10054051/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Car_ST10054051/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "CarNo,CarMake,Model,BodyType,KilometresTravelled,ServiceKilometres,Available")] Car_ST10054051 car_ST10054051)
        {
            if (ModelState.IsValid)
            {
                db.Car_ST10054051.Add(car_ST10054051);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(car_ST10054051);
        }

        // GET: Car_ST10054051/Edit/5
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Car_ST10054051 car_ST10054051 = db.Car_ST10054051.Find(id);
            if (car_ST10054051 == null)
            {
                return HttpNotFound();
            }
            return View(car_ST10054051);
        }

        // POST: Car_ST10054051/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "CarNo,CarMake,Model,BodyType,KilometresTravelled,ServiceKilometres,Available")] Car_ST10054051 car_ST10054051)
        {
            if (ModelState.IsValid)
            {
                db.Entry(car_ST10054051).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(car_ST10054051);
        }

        // GET: Car_ST10054051/Delete/5
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Car_ST10054051 car_ST10054051 = db.Car_ST10054051.Find(id);
            if (car_ST10054051 == null)
            {
                return HttpNotFound();
            }
            return View(car_ST10054051);
        }

        // POST: Car_ST10054051/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            try
            {
                Car_ST10054051 car_ST10054051 = db.Car_ST10054051.Find(id);
                db.Car_ST10054051.Remove(car_ST10054051);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                return View("Error");
            }

        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
