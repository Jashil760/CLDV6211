﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNetCore.Mvc;
using RideYouRentjr2.Models;

namespace RideYouRentjr2.Controllers
{
    [CustomAuthorize(Roles = "Inspector")]
    public class ReturnController : Controller
    {

        private ReturnController db = new ReturnController();

        // GET: Return_ST10054051
        public ActionResult Index()
        {
            var return_ST10054051 = db.Return_ST10054051.Include(r => r.Car_ST10054051).Include(r => r.Driver_ST10054051).Include(r => r.fine_ST10054051).Include(r => r.Inspector_ST10054051);
            return View(return_ST10054051.ToList());
        }

        // GET: Return_ST10054051/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Return_ST10054051 return_ST10054051 = db.Return_ST10054051.Find(id);
            if (return_ST10054051 == null)
            {
                return HttpNotFound();
            }
            return View(return_ST10054051);
        }

        // GET: Return_ST10054051/Create
        public ActionResult Create()
        {
            ViewBag.CarNo = new SelectList(db.Car_ST10054051, "CarNo", "CarNo");
            ViewBag.Driver_id = new SelectList(db.Driver_ST10054051, "driver_id", "fullName");
            ViewBag.Fine_id = new SelectList(db.fine_ST10054051, "fine_id", "fine_id");
            ViewBag.Inspector_no = new SelectList(db.Inspector_ST10054051, "Inspector_no", "fullName");
            return View();
        }

        // POST: Return_ST10054051/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Return_id,CarNo,Inspector_no,Driver_id,ReturnDate,ElapsedDate,Fine_id")] Return_ST10054051 return_ST10054051)
        {
            if (ModelState.IsValid)
            {
                // Find the rental with the given CarNo
                var rental = db.Rental_ST10054051.FirstOrDefault(r => r.CarNo == return_ST10054051.CarNo);
                if (rental != null)
                {
                    // Calculate elapsed days
                    return_ST10054051.ElapsedDate = (return_ST10054051.ReturnDate - rental.End_Date).Days;

                    // Calculate fine
                    var fineAmount = 500 * return_ST10054051.ElapsedDate;

                    // Create a new fine record
                    var newFine = new fine_ST10054051()
                    {
                        fine_id = return_ST10054051.Fine_id,
                        fine = fineAmount // Assuming "amount" is the field to store fine in fine_st10090477
                    };
                    db.fine_ST10054051.Add(newFine);
                }
                db.Return_ST10054051.Add(return_ST10054051);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            //    db.Return_ST10054051.Add(return_ST10054051);
            //    db.SaveChanges();
            //    return RedirectToAction("Index");
            //}

            ViewBag.CarNo = new SelectList(db.Car_ST10054051, "CarNo", "CarMake", return_ST10054051.CarNo);
            ViewBag.Driver_id = new SelectList(db.Driver_ST10054051, "driver_id", "driver_name", return_ST10054051.Driver_id);
            ViewBag.Fine_id = new SelectList(db.fine_ST10054051, "fine_id", "fine_id", return_ST10054051.Fine_id);
            ViewBag.Inspector_no = new SelectList(db.Inspector_ST10054051, "Inspector_no", "first_name", return_ST10054051.Inspector_no);
            return View(return_ST10054051);
        }

        // GET: Return_ST10054051/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Return_ST10054051 return_ST10054051 = db.Return_ST10054051.Find(id);
            if (return_ST10054051 == null)
            {
                return HttpNotFound();
            }
            ViewBag.CarNo = new SelectList(db.Car_ST10054051, "CarNo", "CarMake", return_ST10054051.CarNo);
            ViewBag.Driver_id = new SelectList(db.Driver_ST10054051, "driver_id", "driver_name", return_ST10054051.Driver_id);
            ViewBag.Fine_id = new SelectList(db.fine_ST10054051, "fine_id", "fine_id", return_ST10054051.Fine_id);
            ViewBag.Inspector_no = new SelectList(db.Inspector_ST10054051, "Inspector_no", "first_name", return_ST10054051.Inspector_no);
            return View(return_ST10054051);
        }

        // POST: Return_ST10054051/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Return_id,CarNo,Inspector_no,Driver_id,ReturnDate,ElapsedDate,Fine_id")] Return_ST10054051 return_ST10054051)
        {
            if (ModelState.IsValid)
            {
                db.Entry(return_ST10054051).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CarNo = new SelectList(db.Car_ST10054051, "CarNo", "CarMake", return_ST10054051.CarNo);
            ViewBag.Driver_id = new SelectList(db.Driver_ST10054051, "driver_id", "driver_name", return_ST10054051.Driver_id);
            ViewBag.Fine_id = new SelectList(db.fine_ST10054051, "fine_id", "fine_id", return_ST10054051.Fine_id);
            ViewBag.Inspector_no = new SelectList(db.Inspector_ST10054051, "Inspector_no", "first_name", return_ST10054051.Inspector_no);
            return View(return_ST10054051);
        }

        // GET: Return_ST10054051/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Return_ST10054051 return_ST10054051 = db.Return_ST10054051.Find(id);
            if (return_ST10054051 == null)
            {
                return HttpNotFound();
            }
            return View(return_ST10054051);
        }

        // POST: Return_ST10054051/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Return_ST10054051 return_ST10054051 = db.Return_ST10054051.Find(id);
            db.Return_ST10054051.Remove(return_ST10054051);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
