﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNetCore.Mvc;
using RideYouRentjr2.Models;

namespace RideYouRentjr2.Controllers
{
    [CustomAuthorize(Roles = "Inspector")]
    public class RentalController : Controller
    {

        private RentalController db = new RentalController();

        // GET: Rental_ST10054051
        public ActionResult Index()
        {
            var rental_ST10054051 = db.Rental_ST10054051.Include(r => r.Car_ST10054051).Include(r => r.Driver_ST10054051).Include(r => r.Inspector_ST10054051);
            return View(rental_ST10054051.ToList());
        }

        // GET: Rental_ST10054051/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Rental_ST10054051 rental_ST10054051 = db.Rental_ST10054051.Find(id);
            if (rental_ST10054051 == null)
            {
                return HttpNotFound();
            }
            return View(rental_ST10054051);
        }

        // GET: Rental_ST10054051/Create
        public ActionResult Create()
        {
            ViewBag.CarNo = new SelectList(db.Car_ST10054051, "CarNo", "CarNo");
            ViewBag.Driver_id = new SelectList(db.Driver_ST10054051, "driver_id", "fullName");
            ViewBag.Inspector_no = new SelectList(db.Inspector_ST10054051, "Inspector_no", "fullName");
            return View();
        }

        // POST: Rental_ST10054051/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Rental_id,CarNo,Inspector_no,Driver_id,Rental_Fee,StartDate,End_Date")] Rental_ST10054051 rental_ST10054051)
        {
            if (ModelState.IsValid)
            {               
                db.Rental_ST10054051.Add(rental_ST10054051);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.CarNo = new SelectList(db.Car_ST10054051, "CarNo", "CarMake", rental_ST10054051.CarNo);
            ViewBag.Driver_id = new SelectList(db.Driver_ST10054051, "driver_id", "driver_name", rental_ST10054051.Driver_id);
            ViewBag.Inspector_no = new SelectList(db.Inspector_ST10054051, "Inspector_no", "first_name", rental_ST10054051.Inspector_no);
            return View(rental_ST10054051);
        }

        // GET: Rental_ST10054051/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Rental_ST10054051 rental_ST10054051 = db.Rental_ST10054051.Find(id);
            if (rental_ST10054051 == null)
            {
                return HttpNotFound();
            }
            ViewBag.CarNo = new SelectList(db.Car_ST10054051, "CarNo", "CarMake", rental_ST10054051.CarNo);
            ViewBag.Driver_id = new SelectList(db.Driver_ST10054051, "driver_id", "driver_name", rental_ST10054051.Driver_id);
            ViewBag.Inspector_no = new SelectList(db.Inspector_ST10054051, "Inspector_no", "first_name", rental_ST10054051.Inspector_no);
            return View(rental_ST10054051);
        }

        // POST: Rental_ST10054051/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Rental_id,CarNo,Inspector_no,Driver_id,Rental_Fee,StartDate,End_Date")] Rental_ST10054051 rental_ST10054051)
        {
            if (ModelState.IsValid)
            {
                db.Entry(rental_ST10054051).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CarNo = new SelectList(db.Car_ST10054051, "CarNo", "CarMake", rental_ST10054051.CarNo);
            ViewBag.Driver_id = new SelectList(db.Driver_ST10054051, "driver_id", "driver_name", rental_ST10054051.Driver_id);
            ViewBag.Inspector_no = new SelectList(db.Inspector_ST10054051, "Inspector_no", "first_name", rental_ST10054051.Inspector_no);
            return View(rental_ST10054051);
        }

        // GET: Rental_ST10054051/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Rental_ST10054051 rental_ST10054051 = db.Rental_ST10054051.Find(id);
            if (rental_ST10054051 == null)
            {
                return HttpNotFound();
            }
            return View(rental_ST10054051);
        }

        // POST: Rental_ST10054051/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Rental_ST10054051 rental_ST10054051 = db.Rental_ST10054051.Find(id);
            db.Rental_ST10054051.Remove(rental_ST10054051);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
