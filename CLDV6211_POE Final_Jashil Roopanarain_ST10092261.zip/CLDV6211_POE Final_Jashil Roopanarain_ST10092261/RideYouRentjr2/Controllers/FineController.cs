﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNetCore.Mvc;
using RideYouRentjr2.Models;

namespace RideYouRentjr2.Controllers
{
    [CustomAuthorize(Roles = "Inspector")]
    public class FineController : Controller
    {
        private FineController db = new FineController();

        // GET: fine_ST10054051
        public ActionResult Index()
        {
            return View(db.fine_ST10054051.ToList());
        }

        // GET: fine_ST10054051/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            fine_ST10054051 fine_ST10054051 = db.fine_ST10054051.Find(id);
            if (fine_ST10054051 == null)
            {
                return HttpNotFound();
            }
            return View(fine_ST10054051);
        }

        // GET: fine_ST10054051/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: fine_ST10054051/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "fine_id,fine")] fine_ST10054051 fine_ST10054051)
        {
            if (ModelState.IsValid)
            {
                db.fine_ST10054051.Add(fine_ST10054051);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(fine_ST10054051);
        }

        // GET: fine_ST10054051/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            fine_ST10054051 fine_ST10054051 = db.fine_ST10054051.Find(id);
            if (fine_ST10054051 == null)
            {
                return HttpNotFound();
            }
            return View(fine_ST10054051);
        }

        // POST: fine_ST10054051/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "fine_id,fine")] fine_ST10054051 fine_ST10054051)
        {
            if (ModelState.IsValid)
            {
                db.Entry(fine_ST10054051).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(fine_ST10054051);
        }

        // GET: fine_ST10054051/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            fine_ST10054051 fine_ST10054051 = db.fine_ST10054051.Find(id);
            if (fine_ST10054051 == null)
            {
                return HttpNotFound();
            }
            return View(fine_ST10054051);
        }

        // POST: fine_ST10054051/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            fine_ST10054051 fine_ST10054051 = db.fine_ST10054051.Find(id);
            db.fine_ST10054051.Remove(fine_ST10054051);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
