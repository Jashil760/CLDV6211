/*CREATE DATABASE RideYouRent;
USE RideYouRent;
DROP DATABASE RideYouRent;*/

CREATE TABLE CarMake(
	CarMake_id int NOT NULL PRIMARY KEY,
	Manufacturer varchar(20) NOT NULL,
	Model varchar(50)
);

CREATE TABLE CarBodyType(
	BodyType_id int NOT NULL PRIMARY KEY,
	BodyType varchar(20),
	BodyTypeName varchar(20) NOT NULL   
);

CREATE TABLE Inspector(
	Inspector_id int NOT NULL PRIMARY KEY,
	Inspector_no int,
    InspectorName varchar(50),
    InspectorEmail varchar(50),
    InspectorMobile int
);

CREATE TABLE Driver(
	Driver_id int NOT NULL PRIMARY KEY,
	DriverAddress varchar(50),
    DriverName varchar(50),
    DriverEmail varchar(50),
    DriverMobile int
);

CREATE TABLE Rental(
	Rental_id int NOT NULL PRIMARY KEY,
	CarNo_rent int,
    Inpsector varchar(50),
    Driver varchar(50),
    RentalFee int,
    StartDate date,
    EndDate date
);

CREATE TABLE ReturnVehicle(
	ReturnVehicle_id int NOT NULL PRIMARY KEY,
	CarNo int,
    Inpsector varchar(50),
    Driver varchar(50),
    ReturnDate date,
    ElapsedDate date,
    Fine int
);

CREATE TABLE Car(	
	CarNo int not null,
	Manufacturer varchar(20),
    Model varchar(20),    
    BodyType varchar(20),
    KiloTravelled int,
    Service_car varchar(10),
    Available varchar(10),
	Car_id int NOT NULL PRIMARY KEY,
	CarMake_id int FOREIGN KEY REFERENCES CarMake(CarMake_id),
	BodyType_id int FOREIGN KEY REFERENCES CarBodyType(BodyType_id),
	Inspector_id int FOREIGN KEY REFERENCES Inspector(Inspector_id),
	Driver_id int FOREIGN KEY REFERENCES Driver(Driver_id),
	Rental_id int FOREIGN KEY REFERENCES Rental(Rental_id),
	ReturnVehicle_id int FOREIGN KEY REFERENCES ReturnVehicle(ReturnVehicle_id)
);

INSERT INTO CAR
VALUES('HYU001', 'Hyundai', 'Grand i10 1.0 Motion', 'Hatchback', 1500, 15000, 'Yes'),
	  ('HYU002', 'Hyundai', 'i20 1.2', 'Hatchback', 3000, 15000, 'Yes'),
	  ('BMW001', 'BMW', '320d 1.2', 'Sedan', 20000, 50000, 'Yes'),
	  ('BMW002', 'BMW', '240d 1.4', 'Sedan', 9500, 15000, 'Yes'),
	  ('TOY001', 'Toyota', 'Corolla 1.0', 'Sedan', 15000, 50000, 'Yes'),
	  ('TOY002', 'Toyota', 'Avanza 1.0', 'SUV', 98000, 15000, 'Yes'),
	  ('TOY003', 'Toyota', 'Corolla Quest 1.0', 'Sedan', 15000, 50000, 'Yes'),
	  ('MER001', 'Mercedes Benz', 'C180', 'Sedan', 5200, 15000, 'Yes'),
	  ('MER002', 'Mercedes Benz', 'A200 Sedan', 'Sedan', 4080, 15000, 'Yes'),
	  ('FOR001', 'Ford', 'Fiesta 1.0', 'Sedan', 7600, 15000, 'Yes');

INSERT INTO Rental
VALUES ('HYU001', 'Bud Barnes', 'Gabrielle Clarke', 5000, '2021-08-30', '2021-08-31'),
	   ('HYU002', 'Bud Barnes', 'Gabrielle Clarke', 5000, '2021-09-01', '2021-09-10'),
	   ('FOR001', 'Bud Barnes', 'Geoffrey Franklin', 6500, '2021-09-01', '2021-09-10'),
	   ('BMW002', 'Tracey Reeves', 'Vita Soto', 7000, '2021-09-20', '2021-09-25'),
	   ('TOY002', 'Tracey Reeves', 'Darlene Peters', 5000, '2021-10-03', '2021-10-31'),
	   ('MER001', 'Sandra Goodwin', 'Darlene Peters', 8000, '2021-10-05', '2021-10-15'),
	   ('HYU002', 'Shannon Burke', 'Vernon Hodgson', 5000, '2021-12-01', '2022-02-10'),
	   ('TOY003', 'Shannon Burke', 'Melanie Cunningham', 5000, '2021-08-10', '2021-08-31');

SELECT * FROM Rental

INSERT INTO ReturnVehicle
VALUES ('HYU001', 'Bud Barnes', 'Gabrielle Clarke', '2021-08-31', 0, 0),
	   ('HYU002', 'Bud Barnes', 'Gabrielle Clarke', '2021-09-10', 0, 0),
	   ('FOR001', 'Bud Barnes', 'Geoffrey Franklin', '2021-09-10', 0, 0),
	   ('BMW002', 'Tracey Reeves', 'Vito Soto', '2021-09-30', 5, 2500),
	   ('TOY002', 'Tracey Reeves', 'Darlene Peters', '2021-10-31', 2, 1000),
	   ('MER001', 'Sandra Goodwin', 'Darlene Peters', '2021-10-15', 1, 500),
	   ('HYU002', 'Shannon Burke', 'Vernon Hodgson', '2022-02-10', 0, 0),
	   ('HYU001', 'Shannon Burke', 'Melanie Cunningham', '2021-08-31', 0, 0);

INSERT INTO Driver
VALUES ('I101', 'Bud Barnes', 'bud@therideyourent.com',0821585359),
	   ('I102', 'Tracy Reeves', 'tracy@therideyourent.com', 0822889988),
	   ('I103', 'Sandra Goodwin', 'sandra@therideyourent.com', 0837695468),
	   ('I104', 'Shannon Burke', 'shannon@therideyourent.com', 0837695468);

SELECT * FROM Driver;

INSERT INTO Inspector
VALUES ('Gabrielle Clarke', '917 Heuvel St Botshabelo Free State 9781', 'gorix10987@macauvpn.com', 0837113269),
	   ('Geoffrey Franklin', '1114 Dorp St Paarl Western Cape 7655', 'noceti8743@drlatvia.com', 0847728052),
	   ('Fawn Cooke', '2158 Prospect St Garsfontein Gauteng 0042', 'yegifav388@enamelme.com', 0821966584),
	   ('Darlene Peters', '2529 St. John Street Somerset West Western Cape 7110', 'mayeka4267@macauvpn.com', 0841221244),
	   ('Vita Soto', '1474 Wolmarans St Sundra Mpumalanga 2200', 'wegog55107@drlatvia.com', 0824567924),
	   ('Opal Rehbein', '697 Thutlwa St Letaba Limpopo 0870', 'yiyow34505@enpaypal.com', 0826864938),
	   ('Vernon Hodgson', '1935 Thutlwa St Letsitele Limpopo 0885', 'gifeh11935@enamelme.com', 0855991446),
	   ('Crispin Wheatly', '330 Sandown Rd Cape Town Western Cape 8018', 'likon78255@macauvpn.com', 0838347945),
	   ('Melanie Cunningham', '616 Loop St Atlantis Western Cape 7350', 'sehapeb835@macauvpn.com', 0827329001),
	   ('Kevin Peay', '814 Daffodil Dr Elliotdale Eastern Cape 5118', 'xajic53991@enpaypal.com', 0832077149);

--Question 5
SELECT * FROM Rental
WHERE StartDate BETWEEN  2021-08-01 AND 2021-10-30;

--Question 6
SELECT * FROM Rental
WHERE Inpsector='Bud Barnes';

--Question 7
SELECT Car.Rental_id, Car.Manufacturer
FROM Car
INNER JOIN Rental ON Car.Rental_id=Rental.Rental_id;

--Question 8
SELECT COUNT(*) AS Hyundai_Count
FROM CarMake
WHERE Manufacturer = 'Hyundai';

--Question 9
UPDATE Car SET Model='Focus' WHERE CarNo='FOR001';

--Question 10
SELECT CarNo_rent, Driver, RentalFee, StartDate, EndDate, Car.Available FROM Rental
INNER JOIN Car ON Car.Rental_id=Rental.Rental_id;

--Question 11
SELECT DISTINCT Model FROM Car;

--Question 12
SELECT * FROM Car
WHERE (Service_car - KiloTravelled) <= 9000;

--Question 13
SELECT Rental_id,
DATEDIFF(DAY, StartDate, EndDate) AS days_late,
(DATEDIFF(DAY, StartDate, EndDate) * 500) AS late_fee
FROM Rental
WHERE EndDate < StartDate;